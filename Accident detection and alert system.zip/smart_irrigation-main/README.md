# smart_irrigation
DEployed on 000Webhost
Link: http://sagariot.000webhostapp.com/
