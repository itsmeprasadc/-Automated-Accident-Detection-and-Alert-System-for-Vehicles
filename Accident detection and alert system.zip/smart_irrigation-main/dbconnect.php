<?php

$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "iot";

$con = mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
?>